
# Drug Review Sentiment and Side-Effect Mining

> **Disclaimer:** research and education only. Not medical advice and not a pharmacovigilance system.

## 1. Overview
Built on the UCI Drug Review dataset (Drugs.com patient reviews). The project predicts whether a review is
**negative, neutral or positive** and extracts the **side effects** mentioned, taking negation into account
(so "no nausea" is not reported as a side effect).

## 2. Installation and how to run
**Google Colab (recommended):** paste this whole cell into one cell and run it. Libraries used (scikit-learn, pandas,
numpy, matplotlib, seaborn, requests, joblib) are preinstalled. The dataset downloads automatically; if that fails,
a file-upload button appears for `drugsComTrain_raw.tsv`. A run on 30,000 reviews takes roughly 5 to 10 minutes.
**Own computer:** Python 3.9+, `pip install numpy pandas scikit-learn matplotlib seaborn requests joblib jupyter`.
**Settings** are at the top of the cell (`MAX_ROWS`, `DO_TUNING`, `CV_FOLDS`, `INTERACTIVE`, ...).

## 3. Methodology
* **Preprocessing:** drop rows without review or rating (1 to 10); decode HTML entities; remove URLs and wrapping quotes;
  remove duplicates and reviews under 5 words. Stop words are kept because negations carry sentiment.
* **Labels:** rating 1-4 negative, 5-6 neutral, 7-10 positive (a noisy proxy). Classes are imbalanced, so macro-F1 is the main metric.
* **Features:** words after a negator get a `NOT_` prefix; word TF-IDF (1-2 grams) on the negation-marked text plus character
  TF-IDF (2-5 chars) for misspellings. The pipeline takes raw text, so prediction needs no separate preprocessing.
* **Side effects:** a lexicon of 33 categories; a mention is negated if a negator is within the 3 preceding words of the same clause.
* **Models:** Linear SVM, Logistic Regression, Complement Naive Bayes; C or alpha tuned by grid search (macro-F1) on a subsample.
* **Evaluation:** one stratified 80/20 split; models compared by cross-validated macro-F1 on the training set only (the test set
  plays no part in model choice); the selected model is scored once on the test set (accuracy, balanced accuracy, macro
  precision/recall/F1 with a bootstrap 95% interval, macro ROC-AUC, MCC, confusion matrix, ROC curves). A robustness check tests on
  drugs never seen in training.

## 4. Results
Generated from the actual run in the final section of the cell output and saved to `task4_outputs/results.md`.

## 5. Limitations and ethics
Ratings are a rough stand-in for sentiment; reviews are self-selected; the lexicon finds only listed terms; the negation window is
simple; a mentioned symptom does not prove the drug caused it. Do not use for medical decisions.

## 6. Dataset and citation
Grasser, F., Kallumadi, S., Malberg, H., Zaunseder, S. (2018). Aspect-based sentiment analysis of drug reviews applying
cross-domain and cross-data learning. ICDH 2018. https://archive.ics.uci.edu/dataset/462/drug+review+dataset+drugs+com
