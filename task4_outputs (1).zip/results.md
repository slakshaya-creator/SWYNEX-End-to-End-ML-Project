**Data.** 27,999 cleaned reviews (from 30,000 raw rows), 22,399 train / 5,600 test. Class shares: 24.8% negative, 8.9% neutral, 66.3% positive, so macro-F1 is the main metric.

**Model comparison.** linear svm: CV macro-F1 0.580 (sd 0.003), test macro-F1 0.600; logistic regression: CV macro-F1 0.601 (sd 0.003), test macro-F1 0.611; complement nb: CV macro-F1 0.532 (sd 0.002), test macro-F1 0.539.

**Selected model.** logistic regression (highest cross-validated macro-F1). Test set: accuracy 0.745, balanced accuracy 0.633, macro-F1 0.611 (95% interval 0.597 to 0.627), macro ROC-AUC 0.845, MCC 0.525.

**Per-class.** negative F1 0.702 (P 0.671, R 0.736); neutral F1 0.284 (P 0.233, R 0.363); positive F1 0.847 (P 0.900, R 0.800). Weakest class: neutral. Expected: neutral wording overlaps with both neighbours.

**Robustness.** On drugs unseen in training, macro-F1 was 0.601 vs 0.611 on the random split.

**Side-effect insights.** Of 27,999 cleaned reviews, 61.1% report at least one side effect. The most frequent is anxiety (12.2% of reviews). Among effects with enough mentions, heart palpitations has the lowest mean rating (4.64, -2.35 vs overall). This is an association in self-reported text, not proof of causation.

Figures saved to `task4_outputs/evaluation.png` and `task4_outputs/side_effects.png`.